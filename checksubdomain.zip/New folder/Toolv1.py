import os, sys,time
try:
  from faker import Faker
  from requests import session
  import requests, random, re
  from random import randint
  import concurrent.futures
except:
  os.system("pip install faker")
  os.system("pip install requests")
  os.system("pip install colorama")
  from faker import Faker
  from requests import session
  import requests, random, re
  from random import randint
  import concurrent.futures


def clear():
	if os.name=='nt':os.system('cls')
	else:os.system('clear')
clear()


def checkhotmail():
  print ('')
  print ('             \033[1;34m[ Tool Check SUB Doamin ]')
  print ('')
  try:
    print (" \033[1;34m CÓ THỂ NHẬP ĐỊNH DẠNG MAIL|PASS")
    hotmail = open("domain.txt").readlines()
    hotmail_live = "subdomain.txt"
  except:
    print (" \033[1;31mKHÔNG TÌM THẤY FILE BẠN ĐÃ NHẬP !")
    quit()
  list_hotmail = []
  for line_hotmail in hotmail:
    HotMail = line_hotmail.strip("\n")
    list_hotmail.append(HotMail)
  
  def run_check_hotmail(hot_mail):
    s = session()
    url = f"https://crt.sh/?q=%.{hot_mail}&output=json"
    response = requests.get(url)
    while  response.status_code != 200:
        response = requests.get(url)
    data = response.json()
    subdomains = set()
    for entry in data:
        name_value = entry.get("name_value")
        if name_value:
            subdomain = name_value.split("\n")[0].strip("*.")
            subdomains.add(subdomain)

    for subdomain in subdomains:
        print(f"Subdomain exists: {subdomain}")
        open(hotmail_live,'a').write(subdomain + "\n")

  with concurrent.futures.ThreadPoolExecutor() as executor:
    executor.map(run_check_hotmail, list_hotmail)


def checkyahoo():
  print ('')
  print ('             \033[1;34m[ Tool Check SUB Doamin ]')
  print ('')
  try:
    print (" \033[1;34m CÓ THỂ NHẬP ĐỊNH DẠNG MAIL|PASS")
    hotmail = open("subdomain.txt").readlines()
    hotmail_live = "live.txt"
  except:
    print (" \033[1;31mKHÔNG TÌM THẤY FILE BẠN ĐÃ NHẬP !")
    quit()
  list_hotmail = []
  for line_hotmail in hotmail:
    HotMail = line_hotmail.strip("\n")
    list_hotmail.append(HotMail)
  
  def run_check_hotmail(hot_mail):
    urls = ['/cronmomo', '/gd', '/cron/momo2', '/cron/nmomo', '/tra-thuong', '/cron/tra-thuong', '/trathuong', '/zalo', '/momo2', '/momo', '/cron/zalo.php?type=zalo', '/cron/momo.php?type=zalo', '/cron/momo.php', '/cron/zalo.php', '/cron/momo.php', '/zalo.php', '/momo.php', '/xu-ly-minigame', '/xu-ly-pay']
    for url in urls:
        full_url = 'https://' + hot_mail + url
        try:
            response = requests.head(full_url)
            if response.status_code == requests.codes.ok:
                print(f"Đường dẫn URL {full_url} tồn tại.")
                open(hotmail_live,'a').write(full_url + "\n")
            else:
                print(f"Đường dẫn URL {full_url} không tồn tại.")
        except requests.exceptions.RequestException:
            print(f"Đường dẫn URL {full_url} không tồn tại.")

  with concurrent.futures.ThreadPoolExecutor() as executor:
    executor.map(run_check_hotmail, list_hotmail)



def clr():return f'\033[{random.randint(91,96)}m'

def logo():
  logo = """
                    
        \033[1;36m▀▀█▀▀ █▀▀█ █▀▀█ █░░   \033[1;90m█▀▀ █░░█ █▀▀ █▀▀ █░░█   \033[1;91m█▀▄▀█ █▀▀█ ░▀░ █░░
        \033[1;93m░░█░░ █░░█ █░░█ █░░   \033[1;37m█░░ █▀▀█ █▀▀ █░░ █▀▀█   \033[1;34m█░▀░█ █▄▄█ ▀█▀ █░░
        \033[1;36m░░▀░░ ▀▀▀▀ ▀▀▀▀ ▀▀▀   \033[1;34m▀▀▀ ▀░░▀ ▀▀▀ ▀▀▀ ▀░░▀   \033[1;35m▀░░░▀ ▀░░▀ ▀▀▀ ▀▀▀
                  \033[0;33m By: Kim Hoàng 
                  \033[1;34m Zalo: 0921043784
                  \033[1;32m Facebook : https://www.facebook.com/707311
                  \033[1;32m Box Zalo: https://bots.vn
"""
  for pr in logo:sys.stdout.write(pr);sys.stdout.flush();time.sleep(0.001)


def process_menu():
  menu = """
  
                \033[1;31m[-----------------------------]
                      \033[1;32m1. Tool Check Subdomain.
                      \033[1;33m2. Tool Check Cron.
                      \033[1;35m3. Thoát Tool.
                \033[1;31m[-----------------------------]
  
"""
  for letter in menu:
  	sys.stdout.write(letter)
  	sys.stdout.flush()
  	time.sleep(0.001)
  choice_user = input("\033[1;34m Nhập Lựa Chọn : ")
  if choice_user == '1':
    clear()
    checkhotmail()
  if choice_user == '2':
    clear()
    checkyahoo()
  if choice_user == '3':
    clear()
    print (" Chúc Bạn 1 Ngày Vui Vẻ.")
    quit()
  if choice_user != '1' or '2' or '3' :
    process_menu()
  if choice_user == '':
    process_menu()
logo() 
process_menu()
